$(document).ready(function () {
	
	$('.sp-logo').addClass('animationstart');
	
	setInterval(function () {
		if ($('.sp-logo').hasClass('animationstart')) {				
		}
		else {
			setTimeout(function(){
				$('.sp-logo').addClass('animationstart');
			},1500);
		}		
	}, 1);
	
	setInterval(function () {
		$('.sp-logo').removeClass('animationstart');
	}, 8000);
	
	$("body").addClass("loaded");
	
	setInterval(function () {
		if ($('body').hasClass('loaded')) {				
		}
		else {
			setTimeout(function(){
				$('body').addClass('loaded');
			},1500);
		}		
	}, 1);
	
	setInterval(function () {		
		$('body').removeClass('loaded');
	}, 15000);
	

});